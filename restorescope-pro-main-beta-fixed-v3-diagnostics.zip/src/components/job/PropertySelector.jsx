import { useMemo, useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useAuth } from '@/lib/AuthContext';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Plus, Search, Save, X, Check } from 'lucide-react';

const inputCls = 'w-full min-h-touch px-3 rounded-lg border border-input bg-background text-sm focus:outline-none focus:ring-2 focus:ring-ring transition';
const emptyForm = { address_line_1: '', address_line_2: '', city: '', state: '', zip: '', country: 'United States', occupancy_type: '', structure_type: '', year_built: '', square_feet: '', notes: '' };

function formatAddress(p) {
  return [p.address_line_1, p.address_line_2, p.city, p.state, p.zip].filter(Boolean).join(', ');
}

export default function PropertySelector({ value, onChange }) {
  const { user, userProfile } = useAuth();
  const queryClient = useQueryClient();
  const companyId = user?.company_id || userProfile?.company_id || null;
  const [mode, setMode] = useState('select');
  const [search, setSearch] = useState('');
  const [form, setForm] = useState(emptyForm);
  const [error, setError] = useState('');

  const propertyQuery = useQuery({
    queryKey: ['properties', companyId],
    enabled: !!companyId,
    queryFn: () => base44.entities.Property.filter({ company_id: companyId, is_deleted: false }, 'address_line_1', 250),
    retry: false,
  });

  const properties = Array.isArray(propertyQuery.data) ? propertyQuery.data : [];
  const filtered = useMemo(() => {
    const term = search.trim().toLowerCase();
    if (!term) return properties;
    return properties.filter((property) => [property.address_line_1, property.address_line_2, property.city, property.state, property.zip, property.occupancy_type, property.structure_type]
      .filter(Boolean).join(' ').toLowerCase().includes(term));
  }, [properties, search]);

  const createMutation = useMutation({
    mutationFn: async () => {
      setError('');
      if (!companyId) throw new Error('Your account is not linked to a company.');
      if (!form.address_line_1.trim()) throw new Error('Street address is required.');
      return base44.entities.Property.create({
        company_id: companyId,
        address_line_1: form.address_line_1.trim(),
        address_line_2: form.address_line_2.trim() || null,
        city: form.city.trim() || null,
        state: form.state.trim() || null,
        zip: form.zip.trim() || null,
        country: form.country.trim() || 'United States',
        occupancy_type: form.occupancy_type.trim() || null,
        structure_type: form.structure_type.trim() || null,
        year_built: form.year_built ? Number(form.year_built) : null,
        square_feet: form.square_feet ? Number(form.square_feet) : null,
        notes: form.notes.trim() || null,
        is_deleted: false,
      });
    },
    onSuccess: async (created) => {
      await queryClient.invalidateQueries({ queryKey: ['properties', companyId] });
      onChange(created);
      setForm(emptyForm);
      setSearch('');
      setMode('select');
    },
    onError: (err) => setError(err?.message || 'Failed to save property.'),
  });

  const updateForm = (key) => (event) => setForm((current) => ({ ...current, [key]: event.target.value }));

  if (!companyId) return <div className="rounded-lg border border-destructive/30 bg-destructive/10 p-4 text-sm text-destructive">Your user profile is missing a company ID. Complete company setup first.</div>;

  return (
    <div className="space-y-3">
      {value?.id && (
        <div className="rounded-lg border border-primary/30 bg-primary/5 p-3 flex items-start justify-between gap-3">
          <div className="flex items-start gap-2">
            <Check size={15} className="text-primary mt-0.5" />
            <div>
              <p className="text-sm font-semibold">{value.address_line_1}</p>
              <p className="text-xs text-muted-foreground">{formatAddress(value)}</p>
            </div>
          </div>
          <button type="button" onClick={() => onChange(null)} className="rounded-md p-1 text-muted-foreground hover:bg-muted hover:text-foreground transition"><X size={15} /></button>
        </div>
      )}

      <div className="flex gap-2">
        <button type="button" onClick={() => { setMode('select'); setError(''); }} className={`min-h-touch px-3 rounded-lg border text-sm font-medium transition ${mode === 'select' ? 'bg-primary text-primary-foreground border-primary' : 'border-border hover:bg-muted'}`}>Select Existing</button>
        <button type="button" onClick={() => { setMode('create'); setError(''); }} className={`inline-flex items-center gap-1.5 min-h-touch px-3 rounded-lg border text-sm font-medium transition ${mode === 'create' ? 'bg-primary text-primary-foreground border-primary' : 'border-border hover:bg-muted'}`}><Plus size={15} /> New Property</button>
      </div>

      {mode === 'select' && (
        <div className="space-y-3">
          <div className="relative"><Search size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" /><input className={`${inputCls} pl-9`} value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Search property by address, city, state, or ZIP..." /></div>
          {propertyQuery.isLoading && <div className="rounded-lg border border-border p-4 text-sm text-muted-foreground">Loading property records...</div>}
          {propertyQuery.isError && <div className="rounded-lg border border-destructive/30 bg-destructive/10 p-4 text-sm text-destructive">Failed to load property records.</div>}
          {!propertyQuery.isLoading && filtered.length === 0 && <div className="rounded-lg border border-border p-4 text-sm text-muted-foreground">No property records found. Use New Property to create one.</div>}
          {filtered.length > 0 && <div className="max-h-64 overflow-auto rounded-lg border border-border divide-y divide-border">{filtered.map((property) => <button key={property.id} type="button" onClick={() => onChange(property)} className={`w-full text-left p-3 transition ${value?.id === property.id ? 'bg-primary/10' : 'hover:bg-muted'}`}><p className="text-sm font-medium">{property.address_line_1}</p><p className="text-xs text-muted-foreground">{formatAddress(property)}</p></button>)}</div>}
        </div>
      )}

      {mode === 'create' && (
        <div className="rounded-lg border border-border p-4 space-y-3">
          <Field label="Street Address" required><input className={inputCls} value={form.address_line_1} onChange={updateForm('address_line_1')} placeholder="123 Main Street" /></Field>
          <Field label="Address Line 2"><input className={inputCls} value={form.address_line_2} onChange={updateForm('address_line_2')} placeholder="Unit, suite, apartment" /></Field>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-3"><Field label="City"><input className={inputCls} value={form.city} onChange={updateForm('city')} /></Field><Field label="State"><input className={inputCls} value={form.state} onChange={updateForm('state')} maxLength={2} /></Field><Field label="ZIP"><input className={inputCls} value={form.zip} onChange={updateForm('zip')} /></Field></div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3"><Field label="Occupancy Type"><input className={inputCls} value={form.occupancy_type} onChange={updateForm('occupancy_type')} placeholder="Owner occupied, vacant, tenant..." /></Field><Field label="Structure Type"><input className={inputCls} value={form.structure_type} onChange={updateForm('structure_type')} placeholder="Residential, commercial..." /></Field></div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3"><Field label="Year Built"><input type="number" className={inputCls} value={form.year_built} onChange={updateForm('year_built')} /></Field><Field label="Square Feet"><input type="number" className={inputCls} value={form.square_feet} onChange={updateForm('square_feet')} /></Field></div>
          <Field label="Notes"><textarea className="w-full min-h-20 px-3 py-2 rounded-lg border border-input bg-background text-sm focus:outline-none focus:ring-2 focus:ring-ring transition" value={form.notes} onChange={updateForm('notes')} /></Field>
          {error && <div className="rounded-lg border border-destructive/30 bg-destructive/10 p-3 text-sm text-destructive">{error}</div>}
          <button type="button" onClick={() => createMutation.mutate()} disabled={createMutation.isPending} className="inline-flex items-center gap-2 min-h-touch px-4 rounded-lg bg-primary text-primary-foreground text-sm font-semibold hover:bg-primary/90 transition disabled:opacity-60"><Save size={15} />{createMutation.isPending ? 'Saving...' : 'Save Property'}</button>
        </div>
      )}
    </div>
  );
}

function Field({ label, required, children }) {
  return <div><label className="block text-sm font-medium mb-1.5">{label}{required && <span className="text-destructive ml-0.5">*</span>}</label>{children}</div>;
}
