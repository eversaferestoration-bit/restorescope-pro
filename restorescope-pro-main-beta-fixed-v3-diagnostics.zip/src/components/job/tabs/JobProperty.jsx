import { useEffect, useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useAuth } from '@/lib/AuthContext';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Building2, Edit, RefreshCw, Save, X } from 'lucide-react';

const inputCls = 'w-full min-h-touch px-3 rounded-lg border border-input bg-background text-sm focus:outline-none focus:ring-2 focus:ring-ring transition';
const emptyProperty = { address_line_1: '', address_line_2: '', city: '', state: '', zip: '', country: 'United States', occupancy_type: '', structure_type: '', year_built: '', square_feet: '', notes: '' };
function normalizeProperty(property) { if (!property) return emptyProperty; return { address_line_1: property.address_line_1 || '', address_line_2: property.address_line_2 || '', city: property.city || '', state: property.state || '', zip: property.zip || '', country: property.country || 'United States', occupancy_type: property.occupancy_type || '', structure_type: property.structure_type || '', year_built: property.year_built || '', square_feet: property.square_feet || '', notes: property.notes || '' }; }
function fullAddress(property) { return [property?.address_line_1, property?.address_line_2, property?.city, property?.state, property?.zip].filter(Boolean).join(', '); }

export default function JobProperty({ job }) {
  const { user, userProfile } = useAuth();
  const queryClient = useQueryClient();
  const companyId = user?.company_id || userProfile?.company_id || job?.company_id || null;
  const propertyId = job?.property_id || null;
  const [editing, setEditing] = useState(false);
  const [form, setForm] = useState(emptyProperty);
  const [error, setError] = useState('');

  const propertyQuery = useQuery({
    queryKey: ['job-property', propertyId, companyId],
    enabled: !!propertyId && !!companyId,
    retry: false,
    queryFn: async () => {
      const records = await base44.entities.Property.filter({ id: propertyId, company_id: companyId, is_deleted: false }, '-created_date', 1);
      return Array.isArray(records) && records.length > 0 ? records[0] : null;
    },
  });
  const property = propertyQuery.data || null;
  useEffect(() => { setForm(normalizeProperty(property)); }, [property]);

  const saveMutation = useMutation({
    mutationFn: async () => {
      setError('');
      if (!companyId) throw new Error('Missing company ID.');
      if (!propertyId) throw new Error('No property is linked to this job.');
      if (!form.address_line_1.trim()) throw new Error('Street address is required.');
      return base44.entities.Property.update(propertyId, { company_id: companyId, address_line_1: form.address_line_1.trim(), address_line_2: form.address_line_2.trim() || null, city: form.city.trim() || null, state: form.state.trim() || null, zip: form.zip.trim() || null, country: form.country.trim() || 'United States', occupancy_type: form.occupancy_type.trim() || null, structure_type: form.structure_type.trim() || null, year_built: form.year_built ? Number(form.year_built) : null, square_feet: form.square_feet ? Number(form.square_feet) : null, notes: form.notes.trim() || null, is_deleted: false });
    },
    onSuccess: async () => { await queryClient.invalidateQueries({ queryKey: ['job-property', propertyId, companyId] }); await queryClient.invalidateQueries({ queryKey: ['properties', companyId] }); setEditing(false); },
    onError: (err) => setError(err?.message || 'Failed to save property.'),
  });
  const updateForm = (key) => (event) => setForm((current) => ({ ...current, [key]: event.target.value }));

  if (!job?.id) return <StateCard text="Job could not be loaded." />;
  if (!companyId) return <StateCard danger text="This job or user is missing a company ID. Property details cannot load securely." />;
  if (!propertyId) return <Empty title="No property linked" text="This job does not have a property linked yet. Link a property from the job setup or edit screen." />;
  if (propertyQuery.isLoading) return <div className="bg-card rounded-xl border border-border p-6"><div className="h-5 w-40 bg-muted rounded animate-pulse mb-4" /><div className="h-4 w-full bg-muted rounded animate-pulse mb-2" /><div className="h-4 w-2/3 bg-muted rounded animate-pulse" /></div>;
  if (propertyQuery.isError) return <RetryCard text="Property could not be loaded." onRetry={() => propertyQuery.refetch()} />;
  if (!property) return <div className="bg-card rounded-xl border border-border p-8 text-center"><Building2 className="w-10 h-10 mx-auto mb-3 text-muted-foreground" /><h3 className="font-semibold mb-1">Property not found</h3><p className="text-sm text-muted-foreground mb-4">The linked property could not be found for this company. It may have been deleted or saved under a different company.</p><button type="button" onClick={() => propertyQuery.refetch()} className="inline-flex items-center gap-2 min-h-touch px-4 rounded-lg border border-border text-sm font-medium hover:bg-muted transition"><RefreshCw size={15} /> Retry</button></div>;

  if (editing) return <div className="bg-card rounded-xl border border-border p-5 space-y-4"><div className="flex items-center justify-between gap-3"><div><h2 className="font-semibold font-display">Edit Property</h2><p className="text-sm text-muted-foreground">Update the property linked to this job.</p></div><button type="button" onClick={() => { setForm(normalizeProperty(property)); setEditing(false); setError(''); }} className="inline-flex items-center gap-2 min-h-touch px-3 rounded-lg border border-border text-sm font-medium hover:bg-muted transition"><X size={15} /> Cancel</button></div><div className="grid grid-cols-1 md:grid-cols-2 gap-4"><Field label="Street Address" required><input className={inputCls} value={form.address_line_1} onChange={updateForm('address_line_1')} /></Field><Field label="Address Line 2"><input className={inputCls} value={form.address_line_2} onChange={updateForm('address_line_2')} /></Field><Field label="City"><input className={inputCls} value={form.city} onChange={updateForm('city')} /></Field><Field label="State"><input className={inputCls} value={form.state} onChange={updateForm('state')} maxLength={2} /></Field><Field label="ZIP"><input className={inputCls} value={form.zip} onChange={updateForm('zip')} /></Field><Field label="Country"><input className={inputCls} value={form.country} onChange={updateForm('country')} /></Field><Field label="Occupancy Type"><input className={inputCls} value={form.occupancy_type} onChange={updateForm('occupancy_type')} /></Field><Field label="Structure Type"><input className={inputCls} value={form.structure_type} onChange={updateForm('structure_type')} /></Field><Field label="Year Built"><input type="number" className={inputCls} value={form.year_built} onChange={updateForm('year_built')} /></Field><Field label="Square Feet"><input type="number" className={inputCls} value={form.square_feet} onChange={updateForm('square_feet')} /></Field><div className="md:col-span-2"><Field label="Notes"><textarea className="w-full min-h-24 px-3 py-2 rounded-lg border border-input bg-background text-sm focus:outline-none focus:ring-2 focus:ring-ring transition" value={form.notes} onChange={updateForm('notes')} /></Field></div></div>{error && <div className="rounded-lg border border-destructive/30 bg-destructive/10 p-3 text-sm text-destructive">{error}</div>}<button type="button" onClick={() => saveMutation.mutate()} disabled={saveMutation.isPending} className="inline-flex items-center gap-2 min-h-touch px-4 rounded-lg bg-primary text-primary-foreground text-sm font-semibold hover:bg-primary/90 transition disabled:opacity-60"><Save size={15} />{saveMutation.isPending ? 'Saving...' : 'Save Property'}</button></div>;

  return <div className="bg-card rounded-xl border border-border p-5 space-y-5"><div className="flex items-start justify-between gap-4"><div><h2 className="font-semibold font-display flex items-center gap-2"><Building2 size={18} /> Property</h2><p className="text-sm text-muted-foreground mt-1">{fullAddress(property)}</p></div><button type="button" onClick={() => setEditing(true)} className="inline-flex items-center gap-2 min-h-touch px-3 rounded-lg border border-border text-sm font-medium hover:bg-muted transition"><Edit size={15} /> Edit</button></div><div className="grid grid-cols-1 md:grid-cols-2 gap-4"><Info label="Street Address" value={property.address_line_1} /><Info label="Address Line 2" value={property.address_line_2} /><Info label="City" value={property.city} /><Info label="State" value={property.state} /><Info label="ZIP" value={property.zip} /><Info label="Country" value={property.country} /><Info label="Occupancy Type" value={property.occupancy_type} /><Info label="Structure Type" value={property.structure_type} /><Info label="Year Built" value={property.year_built} /><Info label="Square Feet" value={property.square_feet} /><div className="md:col-span-2"><Info label="Notes" value={property.notes} /></div></div></div>;
}
function Field({ label, required, children }) { return <div><label className="block text-sm font-medium mb-1.5">{label}{required && <span className="text-destructive ml-0.5">*</span>}</label>{children}</div>; }
function Info({ label, value }) { return <div className="rounded-lg border border-border p-3"><p className="text-xs text-muted-foreground mb-1">{label}</p><p className="text-sm font-medium whitespace-pre-wrap">{value || '—'}</p></div>; }
function StateCard({ text, danger }) { return <div className={`bg-card rounded-xl border p-6 text-sm ${danger ? 'border-destructive/30 bg-destructive/10 text-destructive' : 'border-border text-muted-foreground'}`}>{text}</div>; }
function Empty({ title, text }) { return <div className="bg-card rounded-xl border border-border p-8 text-center"><Building2 className="w-10 h-10 mx-auto mb-3 text-muted-foreground" /><h3 className="font-semibold mb-1">{title}</h3><p className="text-sm text-muted-foreground">{text}</p></div>; }
function RetryCard({ text, onRetry }) { return <div className="bg-card rounded-xl border border-destructive/30 bg-destructive/10 p-6"><p className="text-sm text-destructive mb-3">{text}</p><button type="button" onClick={onRetry} className="inline-flex items-center gap-2 min-h-touch px-4 rounded-lg border border-border bg-background text-sm font-medium hover:bg-muted transition"><RefreshCw size={15} /> Retry</button></div>; }
