import { useMemo, useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useAuth } from '@/lib/AuthContext';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Plus, Search, Save, X, Check } from 'lucide-react';

const inputCls = 'w-full min-h-touch px-3 rounded-lg border border-input bg-background text-sm focus:outline-none focus:ring-2 focus:ring-ring transition';
const emptyForm = { full_name: '', email: '', phone: '', billing_address: '', notes: '' };

export default function InsuredSelector({ value, onChange }) {
  const { user, userProfile } = useAuth();
  const queryClient = useQueryClient();
  const companyId = user?.company_id || userProfile?.company_id || null;
  const [mode, setMode] = useState('select');
  const [search, setSearch] = useState('');
  const [form, setForm] = useState(emptyForm);
  const [error, setError] = useState('');

  const insuredQuery = useQuery({
    queryKey: ['insureds', companyId],
    enabled: !!companyId,
    queryFn: () => base44.entities.Insured.filter({ company_id: companyId, is_deleted: false }, 'full_name', 250),
    retry: false,
  });

  const insureds = Array.isArray(insuredQuery.data) ? insuredQuery.data : [];
  const filtered = useMemo(() => {
    const term = search.trim().toLowerCase();
    if (!term) return insureds;
    return insureds.filter((insured) => [insured.full_name, insured.email, insured.phone, insured.billing_address]
      .filter(Boolean).join(' ').toLowerCase().includes(term));
  }, [insureds, search]);

  const createMutation = useMutation({
    mutationFn: async () => {
      setError('');
      if (!companyId) throw new Error('Your account is not linked to a company.');
      if (!form.full_name.trim()) throw new Error('Insured name is required.');
      return base44.entities.Insured.create({
        company_id: companyId,
        full_name: form.full_name.trim(),
        email: form.email.trim() || null,
        phone: form.phone.trim() || null,
        billing_address: form.billing_address.trim() || null,
        notes: form.notes.trim() || null,
        is_deleted: false,
      });
    },
    onSuccess: async (created) => {
      await queryClient.invalidateQueries({ queryKey: ['insureds', companyId] });
      onChange(created);
      setForm(emptyForm);
      setSearch('');
      setMode('select');
    },
    onError: (err) => setError(err?.message || 'Failed to save insured.'),
  });

  const updateForm = (key) => (event) => setForm((current) => ({ ...current, [key]: event.target.value }));

  if (!companyId) {
    return <div className="rounded-lg border border-destructive/30 bg-destructive/10 p-4 text-sm text-destructive">Your user profile is missing a company ID. Complete company setup first.</div>;
  }

  return (
    <div className="space-y-3">
      {value?.id && (
        <div className="rounded-lg border border-primary/30 bg-primary/5 p-3 flex items-start justify-between gap-3">
          <div className="flex items-start gap-2">
            <Check size={15} className="text-primary mt-0.5" />
            <div>
              <p className="text-sm font-semibold">{value.full_name}</p>
              <p className="text-xs text-muted-foreground">{[value.phone, value.email].filter(Boolean).join(' • ') || 'No contact information'}</p>
              {value.billing_address && <p className="text-xs text-muted-foreground mt-1">{value.billing_address}</p>}
            </div>
          </div>
          <button type="button" onClick={() => onChange(null)} className="rounded-md p-1 text-muted-foreground hover:bg-muted hover:text-foreground transition"><X size={15} /></button>
        </div>
      )}

      <div className="flex gap-2">
        <button type="button" onClick={() => { setMode('select'); setError(''); }} className={`min-h-touch px-3 rounded-lg border text-sm font-medium transition ${mode === 'select' ? 'bg-primary text-primary-foreground border-primary' : 'border-border hover:bg-muted'}`}>Select Existing</button>
        <button type="button" onClick={() => { setMode('create'); setError(''); }} className={`inline-flex items-center gap-1.5 min-h-touch px-3 rounded-lg border text-sm font-medium transition ${mode === 'create' ? 'bg-primary text-primary-foreground border-primary' : 'border-border hover:bg-muted'}`}><Plus size={15} /> New Insured</button>
      </div>

      {mode === 'select' && (
        <div className="space-y-3">
          <div className="relative">
            <Search size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
            <input className={`${inputCls} pl-9`} value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Search insured by name, phone, or email..." />
          </div>
          {insuredQuery.isLoading && <div className="rounded-lg border border-border p-4 text-sm text-muted-foreground">Loading insured records...</div>}
          {insuredQuery.isError && <div className="rounded-lg border border-destructive/30 bg-destructive/10 p-4 text-sm text-destructive">Failed to load insured records.</div>}
          {!insuredQuery.isLoading && filtered.length === 0 && <div className="rounded-lg border border-border p-4 text-sm text-muted-foreground">No insured records found. Use New Insured to create one.</div>}
          {filtered.length > 0 && (
            <div className="max-h-64 overflow-auto rounded-lg border border-border divide-y divide-border">
              {filtered.map((insured) => (
                <button key={insured.id} type="button" onClick={() => onChange(insured)} className={`w-full text-left p-3 transition ${value?.id === insured.id ? 'bg-primary/10' : 'hover:bg-muted'}`}>
                  <p className="text-sm font-medium">{insured.full_name}</p>
                  <p className="text-xs text-muted-foreground">{[insured.phone, insured.email].filter(Boolean).join(' • ') || 'No contact information'}</p>
                </button>
              ))}
            </div>
          )}
        </div>
      )}

      {mode === 'create' && (
        <div className="rounded-lg border border-border p-4 space-y-3">
          <Field label="Full Name" required><input className={inputCls} value={form.full_name} onChange={updateForm('full_name')} placeholder="Property owner or insured name" /></Field>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            <Field label="Phone"><input className={inputCls} value={form.phone} onChange={updateForm('phone')} placeholder="Phone number" /></Field>
            <Field label="Email"><input className={inputCls} value={form.email} onChange={updateForm('email')} placeholder="Email address" /></Field>
          </div>
          <Field label="Billing Address"><input className={inputCls} value={form.billing_address} onChange={updateForm('billing_address')} placeholder="Billing address" /></Field>
          <Field label="Notes"><textarea className="w-full min-h-20 px-3 py-2 rounded-lg border border-input bg-background text-sm focus:outline-none focus:ring-2 focus:ring-ring transition" value={form.notes} onChange={updateForm('notes')} /></Field>
          {error && <div className="rounded-lg border border-destructive/30 bg-destructive/10 p-3 text-sm text-destructive">{error}</div>}
          <button type="button" onClick={() => createMutation.mutate()} disabled={createMutation.isPending} className="inline-flex items-center gap-2 min-h-touch px-4 rounded-lg bg-primary text-primary-foreground text-sm font-semibold hover:bg-primary/90 transition disabled:opacity-60"><Save size={15} />{createMutation.isPending ? 'Saving...' : 'Save Insured'}</button>
        </div>
      )}
    </div>
  );
}

function Field({ label, required, children }) {
  return <div><label className="block text-sm font-medium mb-1.5">{label}{required && <span className="text-destructive ml-0.5">*</span>}</label>{children}</div>;
}
