import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { Droplets, AlertCircle } from 'lucide-react';
import { base44 } from '@/api/base44Client';

const EMAIL_REGEX = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

function getUrlErrorMessage() {
  const params = new URLSearchParams(window.location.search);
  const err = params.get('error');
  if (!err) return null;

  if (err === 'wrong_password' || err === 'invalid_password' || err === 'incorrect_password') {
    return 'Incorrect password. Try again or reset your password.';
  }
  if (err === 'user_not_found' || err === 'no_account' || err === 'email_not_found') {
    return 'No account found for this email.';
  }
  if (err === 'incomplete_setup' || err === 'setup_incomplete') {
    return 'Your account exists, but setup needs to be completed.';
  }
  if (err === 'email_exists' || err === 'user_already_exists') {
    return 'An account already exists for this email. Try signing in instead.';
  }
  // Never surface raw error codes or objects
  return null;
}

export default function Login() {
  const [email, setEmail] = useState('');
  const [emailError, setEmailError] = useState('');
  const urlError = getUrlErrorMessage();

  const handleSignIn = () => {
    setEmailError('');
    const trimmed = email.trim();

    if (!trimmed) {
      setEmailError('Enter your email address.');
      return;
    }

    if (!EMAIL_REGEX.test(trimmed)) {
      setEmailError('Enter a valid email address.');
      return;
    }

    console.log('[Login] 🚀 Login start | email:', trimmed);
    console.log('[Login] ➡️ Redirecting to platform login | returnTo: /dashboard');
    base44.auth.redirectToLogin('/dashboard');
  };

  const googleSVG = (
    <svg width="16" height="16" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
      <path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" fill="#4285F4"/>
      <path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853"/>
      <path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l3.66-2.84z" fill="#FBBC05"/>
      <path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" fill="#EA4335"/>
    </svg>
  );

  return (
    <div className="min-h-screen bg-background flex flex-col items-center justify-center px-4 py-12">
      <div className="w-full max-w-sm">
        {/* Logo */}
        <div className="flex items-center justify-center gap-2.5 mb-8">
          <div className="w-10 h-10 rounded-xl bg-primary flex items-center justify-center">
            <Droplets size={20} className="text-white" />
          </div>
          <p className="text-lg font-bold font-display leading-tight">RestoreScope Pro</p>
        </div>

        <div className="bg-card rounded-2xl border border-border shadow-sm p-6">
          <h2 className="text-xl font-semibold font-display mb-1">Welcome back</h2>
          <p className="text-sm text-muted-foreground mb-5">Sign in to your account</p>

          {/* URL-based error message */}
          {urlError && (
            <div className="flex items-start gap-2 bg-destructive/10 border border-destructive/20 rounded-lg px-3 py-2.5 mb-4">
              <AlertCircle size={15} className="text-destructive shrink-0 mt-0.5" />
              <p className="text-sm text-destructive">{urlError}</p>
            </div>
          )}

          {/* Email input (for format validation before redirect) */}
          <div className="mb-3">
            <label className="block text-sm font-medium mb-1.5">Email</label>
            <input
              type="email"
              value={email}
              onChange={(e) => { setEmail(e.target.value); setEmailError(''); }}
              onKeyDown={(e) => e.key === 'Enter' && handleSignIn()}
              placeholder="you@company.com"
              className={`w-full h-10 px-3 rounded-lg border bg-background text-sm focus:outline-none focus:ring-2 focus:ring-ring transition ${emailError ? 'border-destructive' : 'border-input'}`}
            />
            {emailError && (
              <p className="text-xs text-destructive mt-1">{emailError}</p>
            )}
          </div>

          {/* Forgot password — shown prominently */}
          <div className="flex justify-end mb-4">
            <Link
              to="/forgot-password"
              className="text-xs text-primary font-medium hover:underline"
            >
              Forgot your password?
            </Link>
          </div>

          <button
            onClick={handleSignIn}
            className="w-full h-10 rounded-lg bg-primary text-primary-foreground text-sm font-semibold hover:bg-primary/90 transition"
          >
            Sign in
          </button>

          <div className="flex items-center gap-3 my-4">
            <div className="flex-1 h-px bg-border" />
            <span className="text-xs text-muted-foreground">or</span>
            <div className="flex-1 h-px bg-border" />
          </div>

          <button
            onClick={() => base44.auth.redirectToLogin('/dashboard')}
            className="w-full h-10 rounded-lg border border-input bg-background text-sm font-medium hover:bg-muted transition flex items-center justify-center gap-2"
          >
            {googleSVG}
            Continue with Google
          </button>
        </div>

        <p className="text-center text-sm text-muted-foreground mt-5">
          Don't have an account?{' '}
          <Link to="/signup" className="text-primary font-medium hover:underline">
            Sign up
          </Link>
        </p>
      </div>
    </div>
  );
}