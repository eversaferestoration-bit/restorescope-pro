import { createClientFromRequest } from 'npm:@base44/sdk@0.8.26';

const ENTITY_NAMES = [
  'Company','UserProfile','Job','Insured','Property','Claim','Carrier','Adjuster',
  'Room','Photo','Observation','MoistureReading','EnvironmentalReading','EquipmentLog',
  'Containment','EstimateDraft','Supplement','AuditLog','EnterpriseSettings',
  'CompanyLocation','PricingProfile','ClientDocument','Plan','Subscription','UsageRecord'
];

function safeUser(user: any) {
  if (!user) return null;
  return {
    id: user.id || null,
    email: user.email || null,
    role: user.role || null,
    company_id: user.company_id || null,
    companyId: user.companyId || null,
    created_date: user.created_date || null,
  };
}

function cleanRecord(record: any) {
  if (!record || typeof record !== 'object') return record;
  const copy: Record<string, unknown> = {};
  for (const [key, value] of Object.entries(record)) {
    const lower = key.toLowerCase();
    if (
      lower.includes('password') ||
      lower.includes('secret') ||
      lower.includes('token') ||
      lower.includes('apikey') ||
      lower.includes('api_key') ||
      lower.includes('stripe') ||
      lower.includes('private')
    ) {
      copy[key] = '[redacted]';
    } else {
      copy[key] = value;
    }
  }
  return copy;
}

async function inspectEntity(base44: any, entityName: string, companyId: string | null) {
  const entity = base44.asServiceRole?.entities?.[entityName] || base44.entities?.[entityName];

  if (!entity) {
    return {
      exists: false,
      count: 0,
      company_scoped_count: 0,
      missing_company_id_count: 0,
      sample: [],
      error: 'Entity not available from SDK client.',
    };
  }

  try {
    const all = await entity.filter({ is_deleted: false }, '-created_date', 25).catch(() => []);
    const scoped = companyId
      ? await entity.filter({ company_id: companyId, is_deleted: false }, '-created_date', 25).catch(() => [])
      : [];
    const missingCompany = await entity.filter({ company_id: null, is_deleted: false }, '-created_date', 25).catch(() => []);

    return {
      exists: true,
      count: Array.isArray(all) ? all.length : 0,
      company_scoped_count: Array.isArray(scoped) ? scoped.length : 0,
      missing_company_id_count: Array.isArray(missingCompany) ? missingCompany.length : 0,
      sample: Array.isArray(scoped)
        ? scoped.slice(0, 3).map(cleanRecord)
        : [],
      fields_seen: Array.isArray(scoped) && scoped[0] ? Object.keys(scoped[0]).sort() : [],
    };
  } catch (error) {
    return {
      exists: true,
      count: 0,
      company_scoped_count: 0,
      missing_company_id_count: 0,
      sample: [],
      error: error?.message || 'Unable to inspect entity.',
    };
  }
}

async function functionSmokeTest(base44: any, functionName: string) {
  try {
    const response = await base44.functions.invoke(functionName, { diagnostics: true });
    return {
      exists: true,
      ok: true,
      response_keys: response && typeof response === 'object' ? Object.keys(response).slice(0, 20) : [],
    };
  } catch (error) {
    return {
      exists: false,
      ok: false,
      error: error?.message || `Function ${functionName} failed or is not deployed.`,
    };
  }
}

Deno.serve(async (req) => {
  const base44 = createClientFromRequest(req);

  try {
    const user = await base44.auth.me();

    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const role = user.role || 'user';
    const isAdmin = ['admin', 'super_admin', 'platform_admin'].includes(role);

    if (!isAdmin) {
      return Response.json({ error: 'Admin access required' }, { status: 403 });
    }

    const companyId = user.company_id || user.companyId || null;
    const url = new URL(req.url);
    const includeSamples = url.searchParams.get('samples') !== 'false';

    const entityResults: Record<string, unknown> = {};
    for (const entityName of ENTITY_NAMES) {
      const result = await inspectEntity(base44, entityName, companyId);
      if (!includeSamples && result && typeof result === 'object') {
        delete (result as any).sample;
      }
      entityResults[entityName] = result;
    }

    const functionNames = [
      'getUsageReport',
      'getBenchmarkComparison',
      'updateBenchmarks',
      'validateEnterpriseScale',
      'optimizePerformance',
      'deleteUserAccount',
    ];

    const functionResults: Record<string, unknown> = {};
    for (const name of functionNames) {
      functionResults[name] = await functionSmokeTest(base44, name);
    }

    return Response.json({
      generated_at: new Date().toISOString(),
      app: {
        purpose: 'Temporary diagnostic export for RestoreScope Pro beta/production hardening.',
        warning: 'Do not expose this response publicly. Delete this function after debugging.',
      },
      authenticated_user: safeUser(user),
      company_id: companyId,
      entity_diagnostics: entityResults,
      function_diagnostics: functionResults,
      environment_variable_names_needed: [
        'VITE_BASE44_APP_ID',
        'VITE_BASE44_APP_BASE_URL',
        'STRIPE_SECRET_KEY',
        'STRIPE_WEBHOOK_SECRET',
        'OPENAI_API_KEY',
        'RESEND_API_KEY',
        'SMTP_HOST',
        'SMTP_PORT',
        'SMTP_USER',
        'SMTP_PASS',
      ],
      next_steps: [
        'Run this function from Base44 as an admin.',
        'Copy the full JSON response.',
        'Send the JSON response to ChatGPT for final production-hardening fixes.',
        'Delete this function before public beta if you do not need diagnostics anymore.',
      ],
    });
  } catch (error) {
    return Response.json({
      error: error?.message || 'Diagnostic export failed.',
      generated_at: new Date().toISOString(),
    }, { status: 500 });
  }
});
