import { createClientFromRequest } from 'npm:@base44/sdk@0.8.26';

function safeNumber(value: unknown): number {
  const number = Number(value);
  return Number.isFinite(number) ? number : 0;
}

Deno.serve(async (req) => {
  const base44 = createClientFromRequest(req);

  try {
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    const companyId = user.company_id;
    const role = user.role || '';
    const isAdmin = role === 'admin' || role === 'super_admin' || role === 'platform_admin' || role === 'manager';

    if (!companyId) return Response.json({ error: 'Missing company ID' }, { status: 400 });
    if (!isAdmin) return Response.json({ error: 'Forbidden' }, { status: 403 });

    const estimates = await base44.asServiceRole.entities.EstimateDraft.filter({
      company_id: companyId,
      status: 'approved',
      is_deleted: false,
    }, '-created_date', 500).catch(() => []);

    const approved = Array.isArray(estimates) ? estimates : [];
    const totals = approved.map((estimate) => safeNumber(estimate.total || estimate.subtotal)).filter((value) => value > 0);
    const avg = totals.length ? totals.reduce((sum, value) => sum + value, 0) / totals.length : 0;
    const min = totals.length ? Math.min(...totals) : 0;
    const max = totals.length ? Math.max(...totals) : 0;

    const existing = await base44.asServiceRole.entities.PricingTrend.filter({
      region_code: companyId,
      loss_type: 'all',
      category: 'estimate_total',
      is_deleted: false,
    }, '-created_date', 1).catch(() => []);

    const payload = {
      region_code: companyId,
      loss_type: 'all',
      service_type: 'all',
      category: 'estimate_total',
      period: new Date().toISOString(),
      avg_unit_price: avg,
      median_unit_price: avg,
      price_stddev: 0,
      min_price: min,
      max_price: max,
      sample_size: totals.length,
      price_momentum: 0,
      confidence_score: totals.length >= 10 ? 0.8 : totals.length > 0 ? 0.4 : 0,
      is_deleted: false,
    };

    let record;
    if (existing?.[0]?.id) {
      record = await base44.asServiceRole.entities.PricingTrend.update(existing[0].id, payload);
    } else {
      record = await base44.asServiceRole.entities.PricingTrend.create(payload);
    }

    return Response.json({
      success: true,
      updated: true,
      benchmark_id: record?.id || null,
      sample_size: totals.length,
      average_total: avg,
      generated_at: new Date().toISOString(),
    });
  } catch (error) {
    return Response.json({
      success: false,
      updated: false,
      sample_size: 0,
      average_total: 0,
      warning: error?.message || 'Benchmark update fallback returned.',
    });
  }
});
