import { createClientFromRequest } from 'npm:@base44/sdk@0.8.26';

function safeNumber(value: unknown): number {
  const number = Number(value);
  return Number.isFinite(number) ? number : 0;
}

function percentile(value: number, average: number): number | null {
  if (!average || average <= 0) return null;
  const ratio = value / average;
  return Math.max(1, Math.min(99, Math.round(ratio * 50)));
}

function assessment(total: number, marketAverage: number): string {
  if (!marketAverage || marketAverage <= 0) return 'market_aligned';
  const variance = ((total - marketAverage) / marketAverage) * 100;
  if (variance < -15) return 'underpriced';
  if (variance > 15) return 'high_value';
  return 'market_aligned';
}

Deno.serve(async (req) => {
  const base44 = createClientFromRequest(req);

  try {
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    const body = await req.json().catch(() => ({}));
    const estimateId = body.estimate_version_id || body.estimate_id || body.draft_id;
    const companyId = user.company_id;

    if (!companyId) return Response.json({ error: 'Missing company ID' }, { status: 400 });
    if (!estimateId) return Response.json({ error: 'Missing estimate_version_id' }, { status: 400 });

    const estimates = await base44.asServiceRole.entities.EstimateDraft.filter({
      id: estimateId,
      company_id: companyId,
      is_deleted: false,
    }, '-created_date', 1).catch(() => []);

    const estimate = Array.isArray(estimates) ? estimates[0] : null;
    if (!estimate) return Response.json({ error: 'Estimate not found' }, { status: 404 });

    const approved = await base44.asServiceRole.entities.EstimateDraft.filter({
      company_id: companyId,
      status: 'approved',
      is_deleted: false,
    }, '-created_date', 100).catch(() => []);

    const comparable = Array.isArray(approved)
      ? approved.filter((item) => item.id !== estimateId && safeNumber(item.total) > 0)
      : [];

    const estimateTotal = safeNumber(estimate.total || estimate.subtotal);
    const marketAverage = comparable.length
      ? comparable.reduce((sum, item) => sum + safeNumber(item.total || item.subtotal), 0) / comparable.length
      : estimateTotal;

    const variancePct = marketAverage ? ((estimateTotal - marketAverage) / marketAverage) * 100 : 0;
    const lineItems = Array.isArray(estimate.line_items) ? estimate.line_items : [];

    const lineItemAnalysis = lineItems.slice(0, 25).map((item) => {
      const unitCost = safeNumber(item.unit_cost);
      return {
        category: item.category || 'general',
        avg_unit_cost: unitCost,
        market_avg: unitCost,
        variance_pct: 0,
        pricing_indicator: 'market',
      };
    });

    const details = [];
    if (variancePct < -15) details.push('Estimate total appears below the company approved-estimate average. Review for missing scope or pricing omissions.');
    if (variancePct > 15) details.push('Estimate total appears above the company approved-estimate average. Confirm documentation and justification support the pricing.');
    if (!details.length) details.push('Estimate appears aligned with available company benchmark data.');

    return Response.json({
      market_comparison: {
        total_percentile: percentile(estimateTotal, marketAverage),
        overall_assessment: assessment(estimateTotal, marketAverage),
        sample_size: comparable.length,
        estimate_total: estimateTotal,
        market_average: marketAverage,
        variance_pct: variancePct,
        assessment_details: details,
      },
      line_item_analysis: lineItemAnalysis,
      scope_analysis: {
        scope_count: lineItems.length,
        market_scope_count: lineItems.length,
        variance_pct: 0,
      },
      benchmarks_used: {
        total_benchmark: {
          avg: marketAverage,
          sample_size: comparable.length,
        },
      },
      generated_at: new Date().toISOString(),
    });
  } catch (error) {
    return Response.json({
      market_comparison: {
        total_percentile: null,
        overall_assessment: 'market_aligned',
        sample_size: 0,
        estimate_total: 0,
        market_average: 0,
        variance_pct: 0,
        assessment_details: ['Market comparison fallback loaded.'],
      },
      line_item_analysis: [],
      scope_analysis: {
        scope_count: 0,
        market_scope_count: 0,
        variance_pct: 0,
      },
      benchmarks_used: {
        total_benchmark: {
          avg: 0,
          sample_size: 0,
        },
      },
      warning: error?.message || 'Fallback response returned.',
    });
  }
});
